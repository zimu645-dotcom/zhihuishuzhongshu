"""
智汇中枢 - 运行日志面板（专业版）
类似 OpenClaw 网管日志：可筛选、搜索、查看完整错误详情，快速定位问题
"""

import json
import os
from datetime import datetime, timedelta

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QTableWidget, QTableWidgetItem, QHeaderView, QFrame,
    QComboBox, QDateEdit, QLineEdit, QMessageBox,
    QAbstractItemView, QFileDialog, QSplitter, QCheckBox, QSizePolicy
)
from PyQt6.QtCore import Qt, QDate, QTimer
from PyQt6.QtGui import QColor


class LogsPanel(QWidget):
    """专业运行日志面板"""

    LEVELS = ["全部", "ERROR", "WARNING", "INFO", "DEBUG"]

    def __init__(self, config, db, main_window):
        super().__init__()
        self.config = config
        self.db = db
        self.main_window = main_window
        self._current_detail = ""
        self._init_ui()
        self._load_modules()
        self._refresh()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(12)

        # ═══ 顶部：标题 + 统计栏 ═══
        title_row = QHBoxLayout()
        title = QLabel("📝 运行日志")
        title.setObjectName("sectionTitle")
        title_row.addWidget(title)
        title_row.addStretch()

        self.auto_refresh_cb = QCheckBox("🔄 自动刷新 (5s)")
        self.auto_refresh_cb.setChecked(True)
        self.auto_refresh_cb.stateChanged.connect(self._toggle_auto_refresh)
        title_row.addWidget(self.auto_refresh_cb)

        self.export_btn = QPushButton("  📥  导出")
        self.export_btn.clicked.connect(self._on_export)
        self.export_btn.setStyleSheet("border:1px solid #1a73e8;border-radius:4px;padding:4px 12px;color:#1a73e8;")
        title_row.addWidget(self.export_btn)

        layout.addLayout(title_row)

        # ── 统计卡片 ──
        stats_row = QHBoxLayout()
        stats_row.setSpacing(10)
        self._stat_labels = {}
        for key, icon, color in [
            ("TOTAL", "📊 总记录", "#555"),
            ("ERROR", "🔴 错误", "#ff4d4f"),
            ("WARNING", "🟡 警告", "#faad14"),
            ("INFO", "🔵 信息", "#1890ff"),
            ("DEBUG", "⚪ 调试", "#999"),
        ]:
            card = QFrame()
            card.setStyleSheet(
                f"background:{color}08;border:1px solid {color}30;"
                f"border-radius:8px;padding:6px 14px;"
            )
            cl = QHBoxLayout(card)
            cl.setContentsMargins(10, 4, 10, 4)
            lbl = QLabel(f"{icon} 0")
            lbl.setStyleSheet(f"font-size:13px;font-weight:700;color:{color};")
            cl.addWidget(lbl)
            self._stat_labels[key] = lbl
            stats_row.addWidget(card)
        stats_row.addStretch()
        layout.addLayout(stats_row)

        # ── 筛选栏 ──
        filter_frame = QFrame()
        filter_frame.setStyleSheet(
            "background:#fafafa;border:1px solid #eee;border-radius:8px;padding:6px;"
        )
        filter_layout = QHBoxLayout(filter_frame)
        filter_layout.setContentsMargins(12, 6, 12, 6)
        filter_layout.setSpacing(8)

        filter_layout.addWidget(QLabel("级别:"))
        self.level_combo = QComboBox()
        self.level_combo.addItems(self.LEVELS)
        self.level_combo.setFixedWidth(90)
        self.level_combo.currentIndexChanged.connect(self._schedule_refresh)
        filter_layout.addWidget(self.level_combo)

        filter_layout.addWidget(QLabel("模块:"))
        self.module_combo = QComboBox()
        self.module_combo.setFixedWidth(130)
        self.module_combo.currentIndexChanged.connect(self._schedule_refresh)
        filter_layout.addWidget(self.module_combo)

        filter_layout.addWidget(QLabel("搜索:"))
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("关键字搜索消息/操作/错误原因...")
        self.search_input.setFixedWidth(200)
        self.search_input.setClearButtonEnabled(True)
        self.search_input.returnPressed.connect(self._refresh)
        filter_layout.addWidget(self.search_input)

        self.filter_btn = QPushButton("🔍 筛选")
        self.filter_btn.setObjectName("primaryButton")
        self.filter_btn.clicked.connect(self._refresh)
        filter_layout.addWidget(self.filter_btn)

        filter_layout.addWidget(QLabel("从:"))
        self.start_date = QDateEdit()
        self.start_date.setDate(QDate.currentDate().addDays(-1))
        self.start_date.setCalendarPopup(True)
        self.start_date.setFixedWidth(130)
        self.start_date.dateChanged.connect(self._schedule_refresh)
        filter_layout.addWidget(self.start_date)

        filter_layout.addWidget(QLabel("到:"))
        self.end_date = QDateEdit()
        self.end_date.setDate(QDate.currentDate())
        self.end_date.setCalendarPopup(True)
        self.end_date.setFixedWidth(130)
        self.end_date.dateChanged.connect(self._schedule_refresh)
        filter_layout.addWidget(self.end_date)

        self.clear_btn = QPushButton("🗑️ 清空")
        self.clear_btn.clicked.connect(self._on_clear)
        self.clear_btn.setStyleSheet(
            "border:1px solid #ea4335;border-radius:4px;padding:4px 12px;color:#ea4335;"
        )
        filter_layout.addWidget(self.clear_btn)

        layout.addWidget(filter_frame)

        # ═══ 主体：日志表格 + 详情面板（上下分割） ═══
        splitter = QSplitter(Qt.Orientation.Vertical)

        # 日志表格
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["级别", "时间", "模块", "操作", "消息", "耗时"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(30)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        self.table.setColumnWidth(0, 70)
        self.table.setColumnWidth(1, 155)
        self.table.setColumnWidth(2, 85)
        self.table.setColumnWidth(3, 95)
        self.table.setColumnWidth(5, 55)
        self.table.setStyleSheet("""
            QTableWidget {
                border: 1px solid #e8e8e8; border-radius: 8px;
                font-size: 12px;
            }
            QTableWidget::item { padding: 3px 6px; }
            QTableWidget::item:selected {
                background: #e8f0fe; color: #1a1a1a;
            }
            QHeaderView::section {
                padding: 5px 6px; font-weight: bold;
                font-size: 12px; background: #fafafa;
                border: none; border-bottom: 2px solid #e8e8e8;
            }
        """)
        self.table.itemSelectionChanged.connect(self._on_selection_changed)
        splitter.addWidget(self.table)

        # ── 详情面板 ──
        detail_widget = QFrame()
        detail_widget.setStyleSheet(
            "background:#f8f9fa;border:1px solid #e0e0e0;border-radius:8px;"
        )
        detail_layout = QVBoxLayout(detail_widget)
        detail_layout.setContentsMargins(14, 8, 14, 8)
        detail_layout.setSpacing(6)

        dh = QHBoxLayout()
        dt = QLabel("📋 日志详情")
        dt.setStyleSheet("font-size:13px;font-weight:600;color:#333;")
        dh.addWidget(dt)
        dh.addStretch()
        self.copy_btn = QPushButton("📋 复制详情")
        self.copy_btn.setFixedHeight(26)
        self.copy_btn.setStyleSheet(
            "border:1px solid #1a73e8;border-radius:4px;padding:2px 10px;font-size:12px;color:#1a73e8;"
        )
        self.copy_btn.clicked.connect(self._copy_detail)
        self.copy_btn.setEnabled(False)
        dh.addWidget(self.copy_btn)
        detail_layout.addLayout(dh)

        self.detail_label = QLabel("💡 点击上方日志行，在此查看完整详情和错误原因")
        self.detail_label.setWordWrap(True)
        self.detail_label.setStyleSheet(
            "font-size:12px;color:#666;padding:10px;background:white;"
            "border:1px solid #eee;border-radius:6px;line-height:1.6;"
        )
        self.detail_label.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
        )
        detail_layout.addWidget(self.detail_label, 1)
        detail_widget.setMaximumHeight(200)

        splitter.addWidget(detail_widget)
        splitter.setSizes([500, 150])
        layout.addWidget(splitter, 1)

        # ── 状态栏 ──
        self.status_label = QLabel("就绪")
        self.status_label.setStyleSheet("color: #999; font-size: 12px; padding: 2px 0;")
        layout.addWidget(self.status_label)

        # 防抖定时器（避免高频刷新）
        self._debounce_timer = QTimer(self)
        self._debounce_timer.setInterval(300)
        self._debounce_timer.setSingleShot(True)
        self._debounce_timer.timeout.connect(self._refresh)

        # 自动刷新定时器
        self._refresh_timer = QTimer(self)
        self._refresh_timer.setInterval(5000)
        self._refresh_timer.timeout.connect(self._auto_refresh)
        self._refresh_timer.start()

    def _schedule_refresh(self):
        """防抖刷新（避免连点频繁查库）"""
        self._debounce_timer.start()

    def _load_modules(self):
        """从数据库动态加载模块列表"""
        self.module_combo.blockSignals(True)
        current = self.module_combo.currentData()
        self.module_combo.clear()
        self.module_combo.addItem("全部", None)
        for m in self.db.get_distinct_modules():
            self.module_combo.addItem(m, m)
        if current:
            idx = self.module_combo.findData(current)
            if idx >= 0:
                self.module_combo.setCurrentIndex(idx)
        self.module_combo.blockSignals(False)

    def _refresh(self):
        """加载并显示日志"""
        try:
            level = self.level_combo.currentText()
            module = self.module_combo.currentData()
            search = self.search_input.text().strip()
            start = self.start_date.date().toPyDate()
            end = self.end_date.date().toPyDate()

            start_dt = datetime.combine(start, datetime.min.time())
            end_dt = datetime.combine(end, datetime.max.time())

            logs = self.db.query_logs_advanced(
                level=None if level == "全部" else level,
                module=module,
                search_text=search if search else None,
                start_time=start_dt,
                end_time=end_dt,
                limit=500,
            )

            self.table.setRowCount(len(logs))

            icon_map = {"ERROR": "🔴", "WARNING": "🟡", "INFO": "🔵", "DEBUG": "⚪"}
            color_map = {
                "ERROR": ("#ff4d4f", "#fff2f0"),
                "WARNING": ("#faad14", "#fffbe6"),
                "INFO": ("#1890ff", "#e6f7ff"),
                "DEBUG": ("#888", "#f5f5f5"),
            }

            for row, log in enumerate(logs):
                # 级别（图标 + 文字，带颜色）
                icon = icon_map.get(log.level, "⚪")
                li = QTableWidgetItem(f"{icon} {log.level}")
                if log.level in color_map:
                    fg, bg = color_map[log.level]
                    li.setForeground(QColor(fg))
                    li.setBackground(QColor(bg))
                li.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                li.setData(Qt.ItemDataRole.UserRole, log.id)
                self.table.setItem(row, 0, li)

                # 时间
                ts = log.created_at.strftime("%Y-%m-%d %H:%M:%S") if log.created_at else ""
                ti = QTableWidgetItem(ts)
                ti.setForeground(QColor("#666"))
                self.table.setItem(row, 1, ti)

                # 模块
                mi = QTableWidgetItem(log.module)
                mi.setForeground(QColor("#555"))
                mi.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.table.setItem(row, 2, mi)

                # 操作
                ai = QTableWidgetItem(log.action)
                ai.setForeground(QColor("#555"))
                self.table.setItem(row, 3, ai)

                # 消息（截断过长内容）
                msg = log.message[:150]
                if len(log.message) > 150:
                    msg += "..."
                msg_item = QTableWidgetItem(msg)
                if log.level == "ERROR":
                    msg_item.setForeground(QColor("#ff4d4f"))
                self.table.setItem(row, 4, msg_item)

                # 耗时
                dur = str(log.duration_ms) if log.duration_ms is not None else "-"
                di = QTableWidgetItem(dur)
                di.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                di.setForeground(QColor("#999"))
                self.table.setItem(row, 5, di)

            # 更新统计卡片
            stats = self.db.get_log_stats(start_time=start_dt, end_time=end_dt)
            for key in ("TOTAL", "ERROR", "WARNING", "INFO", "DEBUG"):
                lbl = self._stat_labels.get(key)
                if lbl:
                    text = lbl.text()
                    prefix = text.rsplit(" ", 1)[0] if " " in text else text
                    lbl.setText(f"{prefix} {stats.get(key, 0)}")

            self.status_label.setText(
                f"共 {len(logs)} 条记录 | 范围: {start} ~ {end}"
                f"{' | 搜索: ' + search if search else ''}"
            )
        except Exception as e:
            self.status_label.setText(f"⚠️ 刷新失败: {str(e)[:60]}")

    def _auto_refresh(self):
        """定时自动刷新"""
        if self.auto_refresh_cb.isChecked():
            self._refresh()

    def _toggle_auto_refresh(self, state):
        if state == Qt.CheckState.Checked.value:
            self._refresh_timer.start()
        else:
            self._refresh_timer.stop()

    def _on_selection_changed(self):
        """选中某行日志 → 展示完整详情"""
        rows = self.table.selectedItems()
        if not rows:
            self.detail_label.setText("💡 点击上方日志行，在此查看完整详情和错误原因")
            self.copy_btn.setEnabled(False)
            return

        row = rows[0].row()
        log_id = self.table.item(row, 0).data(Qt.ItemDataRole.UserRole)
        if not log_id:
            return

        from app.database import SystemLog
        with self.db.session() as s:
            log = s.query(SystemLog).filter(SystemLog.id == log_id).first()
            if not log:
                return

        lines = []
        lines.append(f"🕐 时间: {log.created_at.strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"📊 级别: {log.level}")
        lines.append(f"📦 模块: {log.module}")
        lines.append(f"⚡ 操作: {log.action}")
        lines.append(f"💬 消息: {log.message}")
        if log.duration_ms is not None:
            lines.append(f"⏱ 耗时: {log.duration_ms}ms")

        # 解析 detail JSON
        if log.detail and log.detail != "{}":
            lines.append("")
            try:
                detail = json.loads(log.detail)
                if isinstance(detail, dict) and detail:
                    lines.append("📎 详细信息 / 错误原因:")
                    for k, v in detail.items():
                        if v is not None and str(v).strip():
                            val = str(v)[:300]
                            lines.append(f"   • {k}: {val}")
                elif isinstance(detail, str) and detail:
                    lines.append(f"📎 详情: {detail[:300]}")
            except json.JSONDecodeError:
                raw = str(log.detail)[:300]
                if raw:
                    lines.append(f"📎 详情: {raw}")

        if log.level == "ERROR":
            lines.append("")
            lines.append("🔴 这是一条错误日志，请根据上方详细信息排查问题。")

        self.detail_label.setText("\n".join(lines))
        self._current_detail = "\n".join(lines)
        self.copy_btn.setEnabled(True)

    def _copy_detail(self):
        """复制当前详情到剪贴板"""
        if not self._current_detail:
            return
        from PyQt6.QtGui import QGuiApplication
        QGuiApplication.clipboard().setText(self._current_detail)
        self.status_label.setText("✅ 详情已复制到剪贴板")
        QTimer.singleShot(3000, lambda: self.status_label.setText("就绪"))

    def _on_export(self):
        """导出日志为 CSV"""
        path, _ = QFileDialog.getSaveFileName(
            self, "导出日志",
            os.path.join(
                self.config.export_dir,
                f"logs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            ),
            "CSV 文件 (*.csv);;文本文件 (*.txt)",
        )
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write("时间,级别,模块,操作,消息,耗时(ms),详情\n")
                for row in range(self.table.rowCount()):
                    vals = []
                    for col in range(self.table.columnCount()):
                        item = self.table.item(row, col)
                        v = item.text() if item else ""
                        if "," in v or '"' in v:
                            v = '"' + v.replace('"', '""') + '"'
                        vals.append(v)
                    # 追加详情列（从详情面板）
                    vals.append("")
                    f.write(",".join(vals) + "\n")
            QMessageBox.information(self, "导出成功", f"日志已导出:\n{path}")
            self.db.add_log("INFO", "system", "export_logs", f"导出日志: {path}")
        except Exception as e:
            QMessageBox.warning(self, "导出失败", str(e))

    def _on_clear(self):
        """清空所有日志"""
        reply = QMessageBox.question(
            self,
            "确认清空",
            "确定要清空所有日志吗？\n此操作不可撤销。",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            with self.db.session() as s:
                from app.database import SystemLog
                s.query(SystemLog).delete()
            self._refresh()
            self.db.add_log("INFO", "system", "clear_logs", "清空所有日志")

    def on_activate(self):
        """页面激活时刷新"""
        self._load_modules()
        self._refresh()
