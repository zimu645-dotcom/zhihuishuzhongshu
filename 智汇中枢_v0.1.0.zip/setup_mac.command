#!/bin/bash
# 智汇中枢 - macOS 一键安装启动脚本
# 用法: chmod +x setup_mac.command && ./setup_mac.command

cd "$(dirname "$0")"
echo "===================================="
echo "  智汇中枢 - macOS 一键安装"
echo "===================================="
echo ""

# 检测 Python 3
if ! command -v python3 &> /dev/null; then
    echo "[错误] 未检测到 Python 3"
    echo "请先安装 Python 3.9 ~ 3.11"
    echo "下载地址: https://www.python.org/downloads/"
    exit 1
fi

# 创建虚拟环境
if [ ! -d "venv" ]; then
    echo "[1/3] 创建虚拟环境..."
    python3 -m venv venv
fi

# 激活虚拟环境
source venv/bin/activate

# 安装依赖
echo "[2/3] 安装依赖..."
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple --quiet

# 启动
echo "[3/3] 启动应用..."
echo ""
echo "===================================="
echo "  安装完成！正在启动..."
echo "===================================="
python3 main.py
