@echo off
chcp 65001 >nul
title ZhihuiZhongshu Installer

echo ====================================
echo   ZhihuiZhongshu - Windows Setup
echo ====================================
echo.
echo  Options:
echo   [1] Install dependencies and run
echo   [2] Build standalone EXE
echo   [3] Exit
echo.

set /p choice="Select (1/2/3): "

if "%choice%"=="1" goto run
if "%choice%"=="2" goto build
exit /b

:run
echo.
echo [1/2] Installing dependencies...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found!
    echo Download: https://www.python.org/downloads/release/python-3119/
    pause
    exit /b
)
python -m venv venv
call venv\Scripts\activate.bat
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
if %errorlevel% neq 0 (
    pause
    exit /b
)
echo [2/2] Starting app...
python main.py
pause
exit /b

:build
echo.
echo [1/3] Installing dependencies...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found!
    echo Download: https://www.python.org/downloads/release/python-3119/
    pause
    exit /b
)
python -m venv venv
call venv\Scripts\activate.bat
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
pip install pyinstaller -q
echo [2/3] Building EXE (5-10 minutes)...
pyinstaller --windowed --onefile --name ZhihuiZhongshu ^
    --hidden-import=PyQt6 ^
    --hidden-import=PyQt6.QtCore ^
    --hidden-import=PyQt6.QtWidgets ^
    --hidden-import=PyQt6.QtGui ^
    --hidden-import=sqlalchemy ^
    --hidden-import=openai ^
    --collect-all PyQt6 ^
    --add-data "core;core" ^
    --add-data "app;app" ^
    --noconfirm ^
    main.py
if %errorlevel% neq 0 (
    echo [ERROR] Build failed!
    pause
    exit /b
)
echo.
echo ====================================
echo   SUCCESS! Output: dist\ZhihuiZhongshu.exe
echo ====================================
pause
